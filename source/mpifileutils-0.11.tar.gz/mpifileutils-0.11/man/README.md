Do not modify these man pages directly.
They are generated from the doc/rst files using sphinx.
After building new man pages, files should be copied over.

    cp doc/build/man/* man/

Be sure to list new tools in man/Makefile.am
