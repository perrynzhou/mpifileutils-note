dgrep
=====

SYNOPSIS
--------

dgrep ...

DESCRIPTION
-----------

OPTIONS
-------

.. option:: -h, --help

   Print a brief message listing the :manpage:`dgrep(1)` options and usage.

.. option:: -v, --version

   Print version information and exit.

Known bugs
~~~~~~~~~~

SEE ALSO
--------

The mpiFileUtils source code and all documentation may be downloaded
from <https://github.com/hpc/mpifileutils>
