/* See the file "COPYING" for the full license governing this code. */

#ifndef __DCP_H_
#define __DCP_H_

#include "common.h"

void DCOPY_print_usage(void);

#endif /* __DCP_H_ */
