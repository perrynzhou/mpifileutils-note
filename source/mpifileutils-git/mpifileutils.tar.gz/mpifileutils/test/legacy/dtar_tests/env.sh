export PATH="`pwd`/../install/include:$PATH"   >& /dev/null
export LD_LIBRARY_PATH="`pwd`/../install/lib:$LD_LIBRARY_PATH"  >&  /dev/null
