for i in {1..100}
do 
   cp ./log.h   $i.h
done

